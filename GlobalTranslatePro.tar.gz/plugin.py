# -*- coding: utf-8 -*-
# Global Translate Pro v5.4 - Grid Interface with Colored Buttons (مثل الثاني)
# Real-time audio translation (DVB, IPTV, AAC) + EPG translation
# Developer: Hamdy Ahmed
# Fully compatible with OpenATV Python 3.13.11
# Added languages: Bosnian, Serbian, Romanian, Hungarian, Polish, Turkish, Portuguese, Kurdish, Croatian, Albanian, Greek, Ukrainian

from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.ChoiceBox import ChoiceBox
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Components.Label import Label
from Components.Button import Button
from Components.ActionMap import ActionMap
from Components.config import config, ConfigSubsection, ConfigYesNo, ConfigSelection, ConfigText
from enigma import eTimer, gRGB
import os
import json
import random
import struct
import subprocess
import re
import requests
import time
import colorsys

# ---------- مسار API Key ----------
API_KEY_PATH = '/etc/enigma2/groq_api_key.txt'

# ---------- GOOGLE TRANSLATE (FALLBACK) ----------
def translate_text(text, target_lang='ar', source_lang='auto'):
    """ترجمة نص باستخدام Google Translate API"""
    if not text or len(text.strip()) < 2:
        return text
    try:
        url = 'https://translate.googleapis.com/translate_a/single'
        params = {
            'client': 'gtx',
            'sl': source_lang,
            'tl': target_lang,
            'dt': 't',
            'q': text[:500]
        }
        response = requests.get(url, params=params, timeout=8)
        if response.status_code == 200:
            data = response.json()
            translated = ''.join([part[0] for part in data[0] if part[0]]).strip()
            if target_lang == 'ar' and re.search(r'[\u0600-\u06FF]', text):
                return text
            if translated and len(translated) > 1:
                return translated
        return text
    except Exception as e:
        print('[Translate] Error:', e)
        return text

# ---------- EPG TRANSLATION (TransEpg) ----------
config.plugins.TransEpg = ConfigSubsection()
config.plugins.TransEpg.enabled = ConfigYesNo(default=True)
config.plugins.TransEpg.language = ConfigSelection(default='ar', choices=[
    ('ar', 'Arabic'), ('en', 'English'), ('fr', 'French'), ('de', 'German'),
    ('it', 'Italian'), ('es', 'Spanish'), ('ru', 'Russian'), ('zh', 'Chinese'), ('ja', 'Japanese'),
    ('bs', 'Bosnian'), ('sr', 'Serbian'), ('ro', 'Romanian'), ('hu', 'Hungarian'),
    ('pl', 'Polish'), ('tr', 'Turkish'), ('pt', 'Portuguese'), ('ku', 'Kurdish'),
    ('hr', 'Croatian'), ('sq', 'Albanian'), ('el', 'Greek'), ('uk', 'Ukrainian')
])
config.plugins.TransEpg.cachepath = ConfigText(default='no path', fixed_size=False)
config.plugins.TransEpg.clearcache = ConfigYesNo(default=False)

class TransEpgController:
    instance = None
    def __init__(self, session):
        TransEpgController.instance = self
        self.session = session
        self.enabled = config.plugins.TransEpg.enabled.value
        cache_path = config.plugins.TransEpg.cachepath.value.strip()
        self.cachepath = cache_path if cache_path and cache_path.lower() != 'no path' else '/tmp/TransEpg_cache.json'
        self.cache = {}
        self._load_cache()
        self._patch_targets()
    def _load_cache(self):
        try:
            if os.path.exists(self.cachepath):
                with open(self.cachepath, 'r') as f:
                    self.cache = json.load(f)
        except Exception as e:
            print('[TransEpg] load error:', e)
    def _save_cache(self):
        try:
            with open(self.cachepath, 'w') as f:
                json.dump(self.cache, f)
        except:
            pass
    def clear_cache(self):
        self.cache = {}
        if os.path.exists(self.cachepath):
            os.remove(self.cachepath)
        print('[TransEpg] cache cleared')
    def translate(self, text):
        if not text or not self.enabled:
            return text
        lang = config.plugins.TransEpg.language.value
        key = f'{lang}|{text}'
        if key in self.cache:
            return self.cache[key]
        translated = translate_text(text, target_lang=lang)
        if translated and translated != text:
            self.cache[key] = translated
            self._save_cache()
            return translated
        return text
    def _patch_targets(self):
        try:
            from Screens.EventView import EventViewBase
            orig = EventViewBase.setEvent
            def new_setEvent(this, event=None):
                orig(this, event)
                if event:
                    name = event.getEventName() or ''
                    desc = (event.getShortDescription() or '') + ('\n\n' + (event.getExtendedDescription() or '') if event.getExtendedDescription() else '')
                    name_t = self.translate(name)
                    desc_t = self.translate(desc)
                    try:
                        this.setTitle(name_t)
                    except:
                        pass
                    for w in ['epg_eventname', 'event_name', 'epg_name']:
                        if w in this:
                            this[w].setText(name_t)
                    if desc_t:
                        for w in ['epg_description', 'description', 'epg_info']:
                            if w in this:
                                this[w].setText(desc_t)
                                break
            EventViewBase.setEvent = new_setEvent
        except:
            pass

# ---------- COLOR MANAGER ----------
class ColorManager:
    COLOR_PALETTES = {
        'vibrant': ['#FF6B6B', '#4ECDC4', '#FFD166', '#06D6A0', '#118AB2', '#EF476F', '#26547C', '#FFD166', '#06D6A0', '#073B4C'],
        'random': ['#FF0000', '#00FF00', '#0000FF', '#FFFF00', '#FF00FF', '#00FFFF', '#FFA500', '#FF4500', '#32CD32', '#9370DB']
    }

    @staticmethod
    def hex_to_gRGB(hex_color):
        hex_color = hex_color.lstrip('#')
        r = int(hex_color[0:2], 16)
        g = int(hex_color[2:4], 16)
        b = int(hex_color[4:6], 16)
        return gRGB(r << 16 | g << 8 | b)

    @staticmethod
    def get_random_color():
        import random
        palette = ColorManager.COLOR_PALETTES['random']
        return random.choice(palette)

    @staticmethod
    def get_sequential_color(index):
        palette = ColorManager.COLOR_PALETTES['vibrant']
        return palette[index % len(palette)]

# ---------- MAIN OVERLAY (Audio Translation) ----------
class TranslatorAIOverlay(Screen):
    def __init__(self, session, mode='DVB'):
        Screen.__init__(self, session)
        self.mode = mode
        self.last_translated_text = ''
        self.stream_process = None
        self.capture_timer = eTimer()
        self.color_index = 0
        self.current_color = '#ffff00'
        self.shadow_enabled = True
        self.retry_count = 0
        
        self.font_size = config.plugins.TranslatorAI.text_size.value
        self.skin = """
        <screen name="TranslatorAIOverlay" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="transparent" zPosition="100">
            <widget name="subtitles" position="480,910" size="960,152" halign="center" valign="center" font="Regular;%s" backgroundColor="#80000000" transparent="0" shadowOffset="2,2" shadowColor="black" />
            <widget name="status" position="5,5" size="479,35" font="Regular;18" foregroundColor="#10808080" backgroundColor="#80000000" />
            <widget name="dev_name" position="674,1104" size="479,30" font="Regular;16" foregroundColor="#bbbbbb" backgroundColor="#80000000" halign="center" />
        </screen>
        """ % self.font_size
        
        self['subtitles'] = Label('')
        self['status'] = Label('Initializing...')
        self['dev_name'] = Label('Developed by: Hamdy Ahmed')
        self['actions'] = ActionMap(['SetupActions', 'ColorActions'], {
            'cancel': self.exit_plugin,
            'exit': self.exit_plugin,
            'red': self.exit_plugin,
            'green': self.toggle_shadow
        }, -2)
        
        self.onLayoutFinish.append(self.apply_all_settings)
        self.startCapture()
    
    def toggle_shadow(self):
        self.shadow_enabled = not self.shadow_enabled
        try:
            if hasattr(self['subtitles'].instance, 'setShadowOffset'):
                if self.shadow_enabled:
                    self['subtitles'].instance.setShadowOffset(2, 2)
                    self['subtitles'].instance.setShadowColor(gRGB(0, 0, 0))
                    self['status'].setText('✓ Shadow ON')
                else:
                    self['subtitles'].instance.setShadowOffset(0, 0)
                    self['status'].setText('✗ Shadow OFF')
            else:
                if self.shadow_enabled:
                    self['subtitles'].setProperty('shadowOffset', '2,2')
                    self['subtitles'].setProperty('shadowColor', 'black')
                else:
                    self['subtitles'].setProperty('shadowOffset', '0,0')
                self['status'].setText('Shadow: ' + ('ON' if self.shadow_enabled else 'OFF'))
            
            if self.last_translated_text:
                self['subtitles'].setText(self.last_translated_text)
        except Exception as e:
            print('[Shadow] Error:', e)
        
        self.status_timer = eTimer()
        self.status_timer.callback.append(self.clear_status_message)
        self.status_timer.start(2000, True)
    
    def clear_status_message(self):
        if hasattr(self, 'status_timer'):
            self.status_timer.stop()
        self['status'].setText('Ready')
    
    def apply_all_settings(self):
        try:
            new_font_size = config.plugins.TranslatorAI.text_size.value
            if new_font_size != self.font_size:
                self.font_size = new_font_size
                shadow_attr = 'shadowOffset="2,2" shadowColor="black"' if self.shadow_enabled else ''
                self.skin = """
                <screen name="TranslatorAIOverlay" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="transparent" zPosition="100">
                    <widget name="subtitles" position="480,910" size="960,152" halign="center" valign="center" font="Regular;%s" backgroundColor="#80000000" transparent="0" %s />
                    <widget name="status" position="5,5" size="479,35" font="Regular;18" foregroundColor="#10808080" backgroundColor="#80000000" />
                    <widget name="dev_name" position="674,1104" size="479,30" font="Regular;16" foregroundColor="#bbbbbb" backgroundColor="#80000000" halign="center" />
                </screen>
                """ % (self.font_size, shadow_attr)
                self.applySkin()
            
            bg_style = config.plugins.TranslatorAI.background_style.value
            if bg_style == 'semi_transparent':
                bg_color = '#70000000'
            elif bg_style == 'ultra_transparent':
                bg_color = '#30000000'
            elif bg_style == 'black':
                bg_color = '#ff000000'
            else:
                bg_color = '#00000000'
            if hasattr(self['subtitles'], 'setBackgroundColor'):
                self['subtitles'].setBackgroundColor(bg_color)
            elif hasattr(self['subtitles'].instance, 'setBackgroundColor'):
                self['subtitles'].instance.setBackgroundColor(bg_color)
            
            pos_y = config.plugins.TranslatorAI.pos_y_selection.value
            try:
                y = int(pos_y)
            except:
                y = 850
            if hasattr(self['subtitles'], 'move'):
                self['subtitles'].move(480, y)
            elif hasattr(self['subtitles'].instance, 'move'):
                self['subtitles'].instance.move(480, y)
            
            self.update_color()
            self['status'].setText(f'Style applied: font {self.font_size}')
        except Exception as e:
            print('[Style] Error:', e)
    
    def update_color(self):
        color_mode = config.plugins.TranslatorAI.text_color.value
        if color_mode == 'random':
            self.current_color = ColorManager.get_random_color()
        elif color_mode == 'sequential':
            self.current_color = ColorManager.get_sequential_color(self.color_index)
            self.color_index += 1
        else:
            color_map = {
                'white': '#ffffff', 'yellow': '#ffff00', 'green': '#00ff00',
                'cyan': '#00ffff', 'orange': '#ff8800', 'blue': '#0000ff'
            }
            self.current_color = color_map.get(color_mode, '#ffffff')
        
        try:
            grgb_color = ColorManager.hex_to_gRGB(self.current_color)
            if hasattr(self['subtitles'], 'instance') and hasattr(self['subtitles'].instance, 'setForegroundColor'):
                self['subtitles'].instance.setForegroundColor(grgb_color)
            elif hasattr(self['subtitles'], 'setForegroundColor'):
                self['subtitles'].setForegroundColor(grgb_color)
            else:
                self['subtitles'].setProperty('foregroundColor', self.current_color)
            
            if self.last_translated_text:
                self['subtitles'].setText(self.last_translated_text)
        except Exception as e:
            print('[Color] Error:', e)
    
    def startCapture(self):
        self.rec_time = int(config.plugins.TranslatorAI.record_duration.value)
        self['status'].setText(f'Starting {self.mode} mode...')
        if self.mode == 'IPTV':
            self.startCaptureIPTV()
        elif self.mode == 'AAC':
            self.startCaptureAAC()
        else:
            self.startCaptureDVB()
    
    def clearProcess(self):
        try:
            os.system('killall -9 gst-launch-1.0 wget ffmpeg curl 2>/dev/null')
        except:
            pass
    
    def startCaptureDVB(self):
        try:
            sref = self.session.nav.getCurrentlyPlayingServiceReference()
            if not sref:
                self['status'].setText('Error: No service playing')
                return
            self.raw_path = '/tmp/continuous_stream.pcm'
            service_str = sref.toString().replace(':', '%3a')
            cmd = f'gst-launch-1.0 -q souphttpsrc location="http://127.0.0.1:8001/{service_str}" ! decodebin ! audioconvert ! audioresample ! audio/x-raw,rate=16000,channels=1,format=S16LE ! filesink location="{self.raw_path}"'
            self.stream_process = subprocess.Popen(cmd, shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            self.capture_timer.callback.append(self.onTimerTrigger)
            self.capture_timer.start(self.rec_time * 1000, True)
            self['status'].setText('Capturing DVB audio...')
        except Exception as e:
            self['status'].setText('Error: ' + str(e)[:30])
    
    def startCaptureIPTV(self):
        try:
            sref = self.session.nav.getCurrentlyPlayingServiceReference()
            if not sref:
                self['status'].setText('Error: No service')
                return
            self.raw_path = '/tmp/continuous_stream.pcm'
            url = sref.getPath()
            if not url or not url.startswith('http'):
                service_str = sref.toString().replace(':', '%3a')
                url = f'http://127.0.0.1:8001/{service_str}'
            self.clearProcess()
            cmd = f'wget -qO- "{url}" 2>/dev/null | gst-launch-1.0 fdsrc ! decodebin ! audioconvert ! audioresample ! audio/x-raw,rate=16000,channels=1,format=S16LE ! filesink location="{self.raw_path}"'
            self.stream_process = subprocess.Popen(cmd, shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            self.capture_timer.callback.append(self.onTimerTrigger)
            self.capture_timer.start(self.rec_time * 1000, True)
            self['status'].setText('Capturing IPTV audio...')
        except Exception as e:
            self['status'].setText('Error: ' + str(e)[:30])
    
    def startCaptureAAC(self):
        try:
            sref = self.session.nav.getCurrentlyPlayingServiceReference()
            if not sref:
                self['status'].setText('Error: No service')
                return
            self.raw_path = '/tmp/continuous_stream.pcm'
            service_str = sref.toString().replace(':', '%3a')
            cmd = f'ffmpeg -i http://127.0.0.1:8001/{service_str} -vn -acodec pcm_s16le -ar 16000 -ac 1 -f s16le - > {self.raw_path}'
            self.stream_process = subprocess.Popen(cmd, shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            self.capture_timer.callback.append(self.onTimerTrigger)
            self.capture_timer.start(self.rec_time * 1000, True)
            self['status'].setText('Capturing AAC audio...')
        except Exception as e:
            self['status'].setText('Error: ' + str(e)[:30])
    
    def onTimerTrigger(self):
        try:
            duration = int(config.plugins.TranslatorAI.record_duration.value)
            bytes_per_sec = 32000
            chunk_size = duration * bytes_per_sec
            if os.path.exists('/tmp/continuous_stream.pcm'):
                with open('/tmp/continuous_stream.pcm', 'rb') as f:
                    f.seek(0,2)
                    file_size = f.tell()
                    if file_size > chunk_size:
                        f.seek(file_size - chunk_size)
                        chunk_data = f.read(chunk_size)
                    else:
                        f.seek(0)
                        chunk_data = f.read()
                if chunk_data and len(chunk_data) > 1000:
                    with open('/tmp/chunk_to_trans.pcm', 'wb') as ftmp:
                        ftmp.write(chunk_data)
                    if self.writeWavHeader('/tmp/chunk_to_trans.pcm', '/tmp/chunk_to_trans.wav'):
                        self.doGroqTranscribe('/tmp/chunk_to_trans.wav')
                    else:
                        self['status'].setText('WAV conversion failed')
                else:
                    self['status'].setText('No audio data')
            else:
                self['status'].setText('No PCM file')
            self.capture_timer.start(duration * 1000, True)
        except Exception as e:
            print('[Timer] error:', e)
            self.capture_timer.start(3000, True)
    
    def writeWavHeader(self, raw_path, wav_path):
        try:
            with open(raw_path, 'rb') as inp:
                audio_data = inp.read()
            if not audio_data or len(audio_data) < 44:
                return False
            
            data_len = len(audio_data)
            with open(wav_path, 'wb') as out:
                out.write(b'RIFF')
                out.write(struct.pack('<I', data_len + 36))
                out.write(b'WAVE')
                out.write(b'fmt ')
                out.write(struct.pack('<I', 16))
                out.write(struct.pack('<H', 1))
                out.write(struct.pack('<H', 1))
                out.write(struct.pack('<I', 16000))
                out.write(struct.pack('<I', 32000))
                out.write(struct.pack('<H', 2))
                out.write(struct.pack('<H', 16))
                out.write(b'data')
                out.write(struct.pack('<I', data_len))
                out.write(audio_data)
            return True
        except Exception as e:
            print('[WAV] Error:', e)
            return False
    
    def doGroqTranscribe(self, wav_path):
        try:
            api_key = config.plugins.TranslatorAI.api_key.value.strip()
            if not api_key:
                self['status'].setText('Error: No API key')
                return
            
            if not os.path.exists(wav_path) or os.path.getsize(wav_path) < 1000:
                self['status'].setText('Audio file too small')
                return
            
            url = 'https://api.groq.com/openai/v1/audio/transcriptions'
            headers = {'Authorization': f'Bearer {api_key}'}
            files = {'file': (os.path.basename(wav_path), open(wav_path, 'rb'), 'audio/wav')}
            data = {'model': 'whisper-large-v3', 'response_format': 'json', 'language': 'en'}
            
            self['status'].setText('Sending to Groq...')
            response = requests.post(url, headers=headers, files=files, data=data, timeout=30)
            
            if response.status_code == 200:
                result = response.json()
                eng_text = result.get('text', '').strip()
                if eng_text and len(eng_text) > 2:
                    self.doTranslate(eng_text)
                else:
                    self['status'].setText('No speech detected')
            else:
                print('[Groq] Error:', response.status_code, response.text)
                self['status'].setText(f'Groq error: {response.status_code}')
        except Exception as e:
            print('[Groq] Exception:', e)
            self['status'].setText('Groq request failed')
    
    def doTranslate(self, eng_text):
        try:
            if not eng_text or len(eng_text) < 3:
                return
            
            blacklist = ['amara', 'subtitle', 'translated', 'watching', 'thank you', 'subscribe', 'copyright', 'شكراً', 'مشاهدة', 'اشترك', 'ترجمة', 'نهاية']
            if any(word in eng_text.lower() for word in blacklist):
                return
            
            target = config.plugins.TranslatorAI.target_language.value
            translated = translate_text(eng_text, target_lang=target)
            
            if translated and translated != self.last_translated_text:
                self.last_translated_text = translated
                max_words = int(config.plugins.TranslatorAI.max_words.value)
                words = re.findall(r'[\w\u0600-\u06FF]+', translated)
                if len(words) > max_words:
                    translated = ' '.join(words[:max_words]) + '...'
                
                self.update_color()
                self['subtitles'].setText(translated)
                self['status'].setText(f'✓ {translated[:40]}')
                self.retry_count = 0
            else:
                self['status'].setText('No new translation')
        except Exception as e:
            print('[Translate] Error:', e)
            self['status'].setText('Translation error')
    
    def exit_plugin(self):
        if self.capture_timer:
            self.capture_timer.stop()
        if self.stream_process:
            self.stream_process.terminate()
            self.stream_process = None
        self.clearProcess()
        for f in ['/tmp/continuous_stream.pcm', '/tmp/chunk_to_trans.pcm', '/tmp/chunk_to_trans.wav']:
            try:
                if os.path.exists(f):
                    os.remove(f)
            except:
                pass
        self.close()

# ---------- GRID SETTINGS SCREEN (مثل البلجن الثاني في الشكل والألوان) ----------
class TranslatorAIGridSettings(Screen):
    """شاشة إعدادات شبكية (4×3) مع تنقل بالأسهم وزر OK وأزهار ملونة أسفل الشاشة"""
    skin = '''
    <screen name="TranslatorAIGridSettings" position="center,center" size="1400,671" title="Global Translate Pro v5.4" backgroundColor="background4" flags="wfBorder">
    <!-- Logo -->
        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlobalTranslatePro/icons/logo.png" position="1027,15" size="110,50" zPosition="-1" transparent="1" alphatest="blend" />
        <!-- Time & Date -->
        <widget source="global.CurrentTime" render="Label" position="1170,10" size="180,35" font="Regular;22" halign="center" foregroundColor="#b8860b" backgroundColor="#160000" transparent="1" zPosition="6">
            <convert type="ClockToText">Format %H:%M:%S</convert>
        </widget>
        <widget source="global.CurrentTime" render="Label" position="1175,40" size="180,35" font="Regular;24" halign="center" foregroundColor="#b8860b" backgroundColor="#160000" transparent="1" zPosition="6">
            <convert type="ClockToText">Format:%d.%m.%Y</convert>
        </widget>
        <!-- عنوان الشاشة -->
        <widget name="title" position="316,15" size="700,50" font="Regular;30" halign="center" valign="center" backgroundColor="#101010" transparent="1" foregroundColor="#fffffe" />
        <!-- عناوين الأعمدة -->
        <widget name="col1_header" position="120,85" size="300,40" font="Regular;26" halign="center" valign="center" foregroundColor="green" backgroundColor="#40000000" transparent="1" />
        <widget name="col2_header" position="530,85" size="300,40" font="Regular;26" halign="center" valign="center" foregroundColor="#bab329" backgroundColor="#40000000" transparent="1" />
        <widget name="col3_header" position="940,85" size="300,40" font="Regular;26" halign="center" valign="center" foregroundColor="#92f1fc" backgroundColor="#40000000" transparent="1" />
        <!-- خلايا الشبكة 4 صفوف × 3 أعمدة -->
        <widget name="cell_0_0" position="130,155" size="280,69" font="Regular;22" halign="left" valign="center" zPosition="2" foregroundColor="white" backgroundColor="#303030" transparent="1" />
        <widget name="cell_0_1" position="540,155" size="280,69" font="Regular;22" halign="left" valign="center" zPosition="2" foregroundColor="white" backgroundColor="#303030" transparent="1" />
        <widget name="cell_0_2" position="950,155" size="280,69" font="Regular;22" halign="left" valign="center" zPosition="2" foregroundColor="white" backgroundColor="#303030" transparent="1" />
        <widget name="cell_1_0" position="130,245" size="280,69" font="Regular;22" halign="left" valign="center" zPosition="2" foregroundColor="white" backgroundColor="#303030" transparent="1" />
        <widget name="cell_1_1" position="540,245" size="280,69" font="Regular;22" halign="left" valign="center" zPosition="2" foregroundColor="white" backgroundColor="#303030" transparent="1" />
        <widget name="cell_1_2" position="950,245" size="280,69" font="Regular;22" halign="left" valign="center" zPosition="2" foregroundColor="white" backgroundColor="#303030" transparent="1" />
        <widget name="cell_2_0" position="130,330" size="280,69" font="Regular;22" halign="left" valign="center" zPosition="2" foregroundColor="white" backgroundColor="#303030" transparent="1" />
        <widget name="cell_2_1" position="540,330" size="280,69" font="Regular;22" halign="left" valign="center" zPosition="2" foregroundColor="white" backgroundColor="#303030" transparent="1" />
        <widget name="cell_2_2" position="950,330" size="280,69" font="Regular;22" halign="left" valign="center" zPosition="2" foregroundColor="white" backgroundColor="#303030" transparent="1" />
        <widget name="cell_3_0" position="130,415" size="280,69" font="Regular;22" halign="left" valign="center" zPosition="2" foregroundColor="white" backgroundColor="#303030" transparent="1" />
        <widget name="cell_3_1" position="540,415" size="280,69" font="Regular;22" halign="left" valign="center" zPosition="2" foregroundColor="white" backgroundColor="#303030" transparent="1" />
        <widget name="cell_3_2" position="950,415" size="280,69" font="Regular;22" halign="left" valign="center" zPosition="2" foregroundColor="white" backgroundColor="#303030" transparent="1" />
        <!-- تمييز الخلية المحددة -->
        <widget name="selection_highlight" position="120,150" size="300,76" zPosition="1" backgroundColor="#800000" borderWidth="1" borderColor="white" transparent="0" />
        <!-- شريط المساعدة -->
        <widget name="help_text" position="60,525" size="1280,40" font="Regular;24" halign="center" valign="center" zPosition="2" foregroundColor="green" backgroundColor="background90" />
        <!-- أزرار التحكم السفلية بألوان البلجن الثاني -->
        <widget name="key_red" position="250,590" size="210,50" font="Regular;24" halign="center" valign="center" backgroundColor="#8b0000" foregroundColor="white" />
        <widget name="key_green" position="490,590" size="210,50" font="Regular;24" halign="center" valign="center" backgroundColor="#006400" foregroundColor="white" />
        <widget name="key_yellow" position="730,590" size="210,50" font="Regular;24" halign="center" valign="center" backgroundColor="#b8860b" foregroundColor="white" />
        <widget name="key_blue" position="970,590" size="210,50" font="Regular;24" halign="center" valign="center" backgroundColor="#1818b4" foregroundColor="white" />
        <!-- خطوط فاصلة -->
        <eLabel position="0,575" size="1400,2" backgroundColor="#ff9800" zPosition="3" />
        <eLabel position="0,80" size="1400,2" backgroundColor="#ff9800" zPosition="3" />
        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlobalTranslatePro/icons/bac.png" position="60,137" size="1280,460" zPosition="-1" transparent="1" />
    </screen>
    '''

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        
        self.rows = 4
        self.cols = 3
        self.current_row = 0
        self.current_col = 0
        
        # محتوى الشبكة: (النص المعروض, النوع, بيانات إضافية)
        self.grid_content = [
            # الصف 0 - الإعدادات الرئيسية
            [
                ('🔑 API Key', 'apikey', {}),
                ('🌐 Target Language', 'choice', {
                    'title': 'اختر اللغة الهدف',
                    'choices': [
                        ('Arabic', 'ar'), ('English', 'en'), ('French', 'fr'), ('German', 'de'),
                        ('Turkish', 'tr'), ('Spanish', 'es'), ('Italian', 'it'), ('Bosnian', 'bs'),
                        ('Serbian', 'sr'), ('Romanian', 'ro'), ('Hungarian', 'hu'), ('Polish', 'pl'),
                        ('Portuguese', 'pt'), ('Kurdish', 'ku'), ('Croatian', 'hr'), ('Albanian', 'sq'),
                        ('Greek', 'el'), ('Ukrainian', 'uk')
                    ],
                    'config': config.plugins.TranslatorAI.target_language
                }),
                ('⏱️ Record Duration', 'choice', {
                    'title': 'مدة التسجيل',
                    'choices': [('3 sec', '3'), ('5 sec', '5'), ('6 sec', '6'), ('8 sec', '8'), ('10 sec', '10')],
                    'config': config.plugins.TranslatorAI.record_duration
                })
            ],
            # الصف 1 - مظهر الترجمة
            [
                ('📝 Max Words', 'choice', {
                    'title': 'الحد الأقصى للكلمات',
                    'choices': [('8 words', '8'), ('10 words', '10'), ('12 words', '12'), ('14 words', '14'), ('16 words', '16'), ('20 words', '20')],
                    'config': config.plugins.TranslatorAI.max_words
                }),
                ('📏 Text Size', 'choice', {
                    'title': 'حجم الخط',
                    'choices': [(str(i), str(i)) for i in [24,28,34,42,44,48,50,52,54,58,60]],
                    'config': config.plugins.TranslatorAI.text_size
                }),
                ('🎨 Text Color', 'choice', {
                    'title': 'لون النص',
                    'choices': [('White','white'),('Yellow','yellow'),('Green','green'),('Cyan','cyan'),
                               ('Orange','orange'),('Blue','blue'),('Random','random'),('Sequential','sequential')],
                    'config': config.plugins.TranslatorAI.text_color
                })
            ],
            # الصف 2 - إعدادات الخلفية و EPG
            [
                ('🎭 Background', 'choice', {
                    'title': 'نمط الخلفية',
                    'choices': [('Semi-Transparent','semi_transparent'),('Ultra Transparent','ultra_transparent'),
                               ('Solid Black','black'),('No Background','transparent')],
                    'config': config.plugins.TranslatorAI.background_style
                }),
                ('📍 Position Y', 'choice', {
                    'title': 'الموقع الرأسي',
                    'choices': [('Top (300)','300'),('Center (540)','540'),('Middle (700)','700'),('Bottom (850)','850')],
                    'config': config.plugins.TranslatorAI.pos_y_selection
                }),
                ('📡 EPG Translation', 'choice', {
                    'title': 'إعدادات EPG',
                    'choices': [('Enabled', 'enabled'), ('Disabled', 'disabled')],
                    'is_epg': True
                })
            ],
            # الصف 3 - أوضاع التشغيل والإجراءات
            [
                ('▶ DVB Mode', 'action', {'callback': self.startOverlayDVB}),
                ('▶ IPTV Mode', 'action', {'callback': self.startOverlayIPTV}),
                ('▶ AAC Mode', 'action', {'callback': self.startOverlayAAC})
            ]
        ]
        
        # إنشاء المتغيرات والعناصر
        self['title'] = Label('Global Translate Pro v5.4 - GRID MODE')
        self['col1_header'] = Label('MAIN CONFIG')
        self['col2_header'] = Label('APPEARANCE')
        self['col3_header'] = Label('ACTIONS')
        
        self.cells = []
        for row in range(self.rows):
            row_cells = []
            for col in range(self.cols):
                cell_name = f'cell_{row}_{col}'
                self[cell_name] = Label('')
                row_cells.append(cell_name)
            self.cells.append(row_cells)
        
        self['selection_highlight'] = Label('')
        self['help_text'] = Label('▲▼◀▶ تحريك • OK تعديل • 1 استيراد API Key • أخضر حفظ • أصفر DVB • أزرق IPTV • 0 AAC • أحمر خروج')
        
        # أزرار ملونة
        self['key_red'] = Button('Exit')
        self['key_green'] = Button('Save')
        self['key_yellow'] = Button('DVB')
        self['key_blue'] = Button('IPTV')
        # إضافة زر 0 (AAC) - غير موجود في السكين لكن سنربطه من الأكشن ماب
        # (يمكن إضافته كـ Button لو أردنا نصاً، ولكن الأزرار الموجودة كافية مع استخدام الرقم 0)
        
        self['actions'] = ActionMap(['SetupActions', 'ColorActions', 'NumberActions', 'DirectionActions'], {
            'cancel': self.close,
            'exit': self.close,
            'red': self.close,
            'green': self.saveSettings,
            'yellow': self.startOverlayDVB,
            'blue': self.startOverlayIPTV,
            '0': self.startOverlayAAC,
            '1': self.importApiKeyFromFile,
            'ok': self.activateCurrentCell,
            'up': self.moveUp,
            'down': self.moveDown,
            'left': self.moveLeft,
            'right': self.moveRight,
            'upRepeated': self.moveUp,
            'downRepeated': self.moveDown,
            'leftRepeated': self.moveLeft,
            'rightRepeated': self.moveRight
        }, -2)
        
        self.onLayoutFinish.append(self.updateAllCells)
        self.onLayoutFinish.append(self.updateSelection)
    
    def updateAllCells(self):
        for row in range(self.rows):
            for col in range(self.cols):
                self.updateCell(row, col)
    
    def updateCell(self, row, col):
        cell_data = self.grid_content[row][col]
        label = cell_data[0]
        typ = cell_data[1]
        params = cell_data[2]
        
        if typ == 'apikey':
            key = config.plugins.TranslatorAI.api_key.value
            if key:
                masked = key[:8] + '...' + key[-4:] if len(key) > 15 else key[:8] + '...'
                value = masked
            else:
                value = 'Not set'
            display = f'{label}\n[{value}]'
        elif typ == 'choice':
            if params.get('is_epg'):
                if config.plugins.TransEpg.enabled.value:
                    lang = config.plugins.TransEpg.language.value
                    lang_names = {
                        'ar':'Arabic','en':'English','fr':'French','de':'German','it':'Italian',
                        'es':'Spanish','ru':'Russian','zh':'Chinese','ja':'Japanese','bs':'Bosnian',
                        'sr':'Serbian','ro':'Romanian','hu':'Hungarian','pl':'Polish','tr':'Turkish',
                        'pt':'Portuguese','ku':'Kurdish','hr':'Croatian','sq':'Albanian','el':'Greek','uk':'Ukrainian'
                    }
                    value = f'Enabled ({lang_names.get(lang, lang)})'
                else:
                    value = 'Disabled'
            else:
                config_obj = params.get('config')
                if config_obj:
                    # تحويل القيم إلى نص مقروء
                    if config_obj == config.plugins.TranslatorAI.target_language:
                        lang_names = {'ar':'Arabic','en':'English','fr':'French','de':'German','tr':'Turkish',
                                     'es':'Spanish','it':'Italian','bs':'Bosnian','sr':'Serbian','ro':'Romanian',
                                     'hu':'Hungarian','pl':'Polish','pt':'Portuguese','ku':'Kurdish',
                                     'hr':'Croatian','sq':'Albanian','el':'Greek','uk':'Ukrainian'}
                        value = lang_names.get(config_obj.value, config_obj.value)
                    elif config_obj == config.plugins.TranslatorAI.record_duration:
                        value = config_obj.value + ' sec'
                    elif config_obj == config.plugins.TranslatorAI.max_words:
                        value = config_obj.value + ' words'
                    elif config_obj == config.plugins.TranslatorAI.text_size:
                        value = config_obj.value
                    elif config_obj == config.plugins.TranslatorAI.text_color:
                        color_names = {'white':'White','yellow':'Yellow','green':'Green','cyan':'Cyan',
                                      'orange':'Orange','blue':'Blue','random':'Random','sequential':'Sequential'}
                        value = color_names.get(config_obj.value, config_obj.value)
                    elif config_obj == config.plugins.TranslatorAI.background_style:
                        bg_names = {'semi_transparent':'Semi-Trans','ultra_transparent':'Ultra Trans',
                                   'black':'Solid Black','transparent':'No BG'}
                        value = bg_names.get(config_obj.value, config_obj.value)
                    elif config_obj == config.plugins.TranslatorAI.pos_y_selection:
                        pos_names = {'300':'Top','540':'Center','700':'Middle','850':'Bottom'}
                        value = pos_names.get(config_obj.value, config_obj.value)
                    else:
                        value = config_obj.value
                else:
                    value = ''
            display = f'{label}\n[{value}]'
        elif typ == 'action':
            display = label
        else:
            display = label
        
        # اختصار النص الطويل
        if len(display) > 28:
            display = display[:25] + '...'
        self[self.cells[row][col]].setText(display)
    
    def updateSelection(self):
        base_x = 120
        base_y = 150
        cell_width = 300
        cell_height = 76
        col_spacing = 110
        row_spacing = 10
        
        x = base_x + (self.current_col * (cell_width + col_spacing))
        y = base_y + (self.current_row * (cell_height + row_spacing))
        self['selection_highlight'].setPosition(x, y)
        
        # تحديث نص المساعدة حسب الخلية المحددة
        cell_label = self.grid_content[self.current_row][self.current_col][0]
        self['help_text'].setText(f'Selected: {cell_label} • OK edit • 1 import API key')
    
    def moveUp(self):
        if self.current_row > 0:
            self.current_row -= 1
            self.updateSelection()
    
    def moveDown(self):
        if self.current_row < self.rows - 1:
            self.current_row += 1
            self.updateSelection()
    
    def moveLeft(self):
        if self.current_col > 0:
            self.current_col -= 1
            self.updateSelection()
    
    def moveRight(self):
        if self.current_col < self.cols - 1:
            self.current_col += 1
            self.updateSelection()
    
    def activateCurrentCell(self):
        row, col = self.current_row, self.current_col
        cell_data = self.grid_content[row][col]
        typ = cell_data[1]
        params = cell_data[2]
        
        if typ == 'apikey':
            self.openApiKeyInput()
        elif typ == 'choice':
            if params.get('is_epg'):
                self.openEpgChoice()
            else:
                self.openChoiceBox(params['title'], params['choices'], params.get('config'))
        elif typ == 'action':
            callback = params.get('callback')
            if callback:
                callback()
    
    def openApiKeyInput(self):
        current = config.plugins.TranslatorAI.api_key.value
        self.session.openWithCallback(self.apiKeyCallback, VirtualKeyBoard, title='Enter Groq API Key:', text=current)
    
    def apiKeyCallback(self, key):
        if key and key.strip():
            config.plugins.TranslatorAI.api_key.value = key.strip()
            config.plugins.TranslatorAI.api_key.save()
            self.saveApiKeyToFile(key.strip())
            self.session.open(MessageBox, '✓ API Key saved successfully!', MessageBox.TYPE_INFO, timeout=2)
            self.updateCell(0, 0)
    
    def saveApiKeyToFile(self, key):
        try:
            os.makedirs(os.path.dirname(API_KEY_PATH), exist_ok=True)
            with open(API_KEY_PATH, 'w') as f:
                f.write(key.strip())
        except Exception as e:
            print('[API] Error saving to file:', e)
    
    def importApiKeyFromFile(self):
        try:
            if os.path.exists(API_KEY_PATH):
                with open(API_KEY_PATH, 'r') as f:
                    key = f.readline().strip()
                if key and len(key) > 10:
                    config.plugins.TranslatorAI.api_key.value = key
                    config.plugins.TranslatorAI.api_key.save()
                    masked = key[:8] + '...' + key[-4:] if len(key) > 15 else key[:8] + '...'
                    self.session.open(MessageBox, f'✓ API Key imported from {API_KEY_PATH}\nKey: {masked}', MessageBox.TYPE_INFO, timeout=3)
                    self.updateCell(0, 0)
                    return
            self.session.open(MessageBox, f'No valid API key found.\nPlace groq_api_key.txt in:\n{API_KEY_PATH}', MessageBox.TYPE_ERROR, timeout=3)
        except Exception as e:
            self.session.open(MessageBox, f'Error importing key: {str(e)}', MessageBox.TYPE_ERROR, timeout=3)
    
    def openChoiceBox(self, title, choices, config_obj):
        choice_list = [(c[0], c[1]) for c in choices]
        self.session.openWithCallback(
            lambda res: self.choiceCallback(res, config_obj),
            ChoiceBox, title=title, list=choice_list
        )
    
    def choiceCallback(self, result, config_obj):
        if result and len(result) >= 1:
            selected_text, selected_value = result
            config_obj.value = selected_value
            config_obj.save()
            self.session.open(MessageBox, f'✓ Setting saved: {selected_text}', MessageBox.TYPE_INFO, timeout=2)
            self.updateAllCells()
    
    def openEpgChoice(self):
        # أولاً اختيار تمكين/تعطيل
        self.session.openWithCallback(
            self.epgEnableCallback,
            ChoiceBox, title='Enable EPG Translation?', list=[('Yes','enabled'),('No','disabled')]
        )
    
    def epgEnableCallback(self, result):
        if result:
            enable = (result[1] == 'enabled')
            config.plugins.TransEpg.enabled.value = enable
            config.plugins.TransEpg.save()
            if enable:
                # ثم اختيار اللغة
                lang_choices = [
                    ('Arabic','ar'),('English','en'),('French','fr'),('German','de'),
                    ('Italian','it'),('Spanish','es'),('Russian','ru'),('Chinese','zh'),('Japanese','ja'),
                    ('Bosnian','bs'),('Serbian','sr'),('Romanian','ro'),('Hungarian','hu'),
                    ('Polish','pl'),('Turkish','tr'),('Portuguese','pt'),('Kurdish','ku'),
                    ('Croatian','hr'),('Albanian','sq'),('Greek','el'),('Ukrainian','uk')
                ]
                self.session.openWithCallback(
                    self.epgLangCallback,
                    ChoiceBox, title='Select EPG Language:', list=lang_choices
                )
            else:
                self.updateCell(2,2)
                self.session.open(MessageBox, 'EPG Translation disabled', MessageBox.TYPE_INFO, timeout=2)
    
    def epgLangCallback(self, result):
        if result:
            lang = result[1]
            config.plugins.TransEpg.language.value = lang
            config.plugins.TransEpg.save()
            self.updateCell(2,2)
            self.session.open(MessageBox, f'✓ EPG Language set to {result[0]}', MessageBox.TYPE_INFO, timeout=2)
    
    def saveSettings(self):
        config.plugins.TranslatorAI.save()
        config.plugins.TransEpg.save()
        if config.plugins.TransEpg.clearcache.value and TransEpgController.instance:
            TransEpgController.instance.clear_cache()
            config.plugins.TransEpg.clearcache.value = False
        self.session.open(MessageBox, '✓ All settings saved successfully!', MessageBox.TYPE_INFO, timeout=2)
    
    def startOverlayDVB(self):
        if not config.plugins.TranslatorAI.api_key.value.strip():
            self.session.open(MessageBox, 'Please set Groq API key first!\nPress 1 to import or edit API Key cell.', MessageBox.TYPE_ERROR, timeout=3)
            return
        self.session.open(TranslatorAIOverlay, mode='DVB')
        self.close()
    
    def startOverlayIPTV(self):
        if not config.plugins.TranslatorAI.api_key.value.strip():
            self.session.open(MessageBox, 'Please set Groq API key first!', MessageBox.TYPE_ERROR, timeout=3)
            return
        self.session.open(TranslatorAIOverlay, mode='IPTV')
        self.close()
    
    def startOverlayAAC(self):
        if not config.plugins.TranslatorAI.api_key.value.strip():
            self.session.open(MessageBox, 'Please set Groq API key first!', MessageBox.TYPE_ERROR, timeout=3)
            return
        self.session.open(TranslatorAIOverlay, mode='AAC')
        self.close()

# ---------- CONFIGURATION (جميع الخيارات مع اللغات الإضافية) ----------
config.plugins.TranslatorAI = ConfigSubsection()
config.plugins.TranslatorAI.api_key = ConfigText(default='', visible_width=50, fixed_size=False)
config.plugins.TranslatorAI.target_language = ConfigSelection(default='ar', choices=[
    ('ar','Arabic'), ('en','English'), ('fr','French'), ('de','German'),
    ('tr','Turkish'), ('es','Spanish'), ('it','Italian'),
    ('bs','Bosnian'), ('sr','Serbian'), ('ro','Romanian'), ('hu','Hungarian'),
    ('pl','Polish'), ('pt','Portuguese'), ('ku','Kurdish'), ('hr','Croatian'),
    ('sq','Albanian'), ('el','Greek'), ('uk','Ukrainian')
])
config.plugins.TranslatorAI.record_duration = ConfigSelection(default='6', choices=[('3','3 sec'),('5','5 sec'),('6','6 sec'),('8','8 sec'),('10','10 sec')])
config.plugins.TranslatorAI.max_words = ConfigSelection(default='10', choices=[('8','8 words'),('10','10 words'),('12','12 words'),('14','14 words'),('16','16 words'),('20','20 words')])
config.plugins.TranslatorAI.text_size = ConfigSelection(default='34', choices=[(str(i),str(i)) for i in [24,28,34,42,44,48,50,52,54,58,60]])
config.plugins.TranslatorAI.text_color = ConfigSelection(default='yellow', choices=[
    ('white','White'), ('yellow','Yellow'), ('green','Green'), ('cyan','Cyan'),
    ('orange','Orange'), ('blue','Blue'), ('random','Random'), ('sequential','Sequential')
])
config.plugins.TranslatorAI.background_style = ConfigSelection(default='semi_transparent', choices=[
    ('semi_transparent','Semi-Transparent'), ('ultra_transparent','Ultra Transparent'),
    ('black','Solid Black'), ('transparent','No Background')
])
config.plugins.TranslatorAI.pos_y_selection = ConfigSelection(default='850', choices=[
    ('300','Top (300)'), ('540','Center (540)'), ('700','Middle (700)'), ('850','Bottom (850)')
])

# ---------- SESSION START ----------
def sessionstart(*args, **kwargs):
    session = None
    if args:
        first = args[0]
        if isinstance(first, int) and len(args) > 1:
            session = args[1]
        elif not isinstance(first, int):
            session = first
    else:
        session = kwargs.get('session')
    if session:
        try:
            TransEpgController(session)
            # محاولة استيراد API key من الملف عند بدء الجلسة
            if os.path.exists(API_KEY_PATH):
                with open(API_KEY_PATH, 'r') as f:
                    key = f.readline().strip()
                if key and not config.plugins.TranslatorAI.api_key.value:
                    config.plugins.TranslatorAI.api_key.value = key
                    config.plugins.TranslatorAI.api_key.save()
                    print('[GlobalTranslate] API key auto-imported from file')
        except Exception as e:
            print('[GlobalTranslate] Controller error:', e)

def main(session, **kwargs):
    session.open(TranslatorAIGridSettings)

def Plugins(**kwargs):
    return [
        PluginDescriptor(name='Global Translate Pro', description='Real-time audio + EPG translation (DVB/IPTV/AAC) | Grid Interface | by Hamdy Ahmed', where=PluginDescriptor.WHERE_PLUGINMENU, icon='plugin.png', fnc=main),
        PluginDescriptor(where=PluginDescriptor.WHERE_SESSIONSTART, fnc=sessionstart)
    ]